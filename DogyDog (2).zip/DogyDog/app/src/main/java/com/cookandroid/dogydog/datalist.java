package com.cookandroid.dogydog;

import android.net.Uri;

import java.io.Serializable;

public class datalist implements Serializable {
    String dogname;
    String phoneno;
    String dogbreed;
    boolean dogstring;
    String dogsize;
    datalist(String dogname,String phoneno,String dogbreed,boolean dogstring, String dogsize){
        this.dogname=dogname;
        this.phoneno=phoneno;
        this.dogbreed=dogbreed;
        this.dogstring=dogstring;
        this.dogsize=dogsize;
    }

}
