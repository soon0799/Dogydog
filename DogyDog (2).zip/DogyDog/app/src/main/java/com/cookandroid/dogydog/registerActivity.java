package com.cookandroid.dogydog;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;

import java.net.URI;
import java.util.ArrayList;

public class registerActivity extends AppCompatActivity {

    private final int GET_GALLERY_IMAGE = 200;
    private ImageView imageview;
    private EditText dogname;
    private EditText dogbreed;
    private EditText phoneno;
    public datalist datalist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        imageview = (ImageView)findViewById(R.id.image);
        imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
                startActivityForResult(intent,GET_GALLERY_IMAGE);
            }
        });

        CheckBox checkBox = (CheckBox)findViewById(R.id.checkBox);
        Spinner spinner = (Spinner)findViewById((R.id.spinner1)) ;

        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),lookingActivity.class);
                startActivity(intent);
            }
        });

        dogname = (EditText) findViewById(R.id.DogName);
        dogbreed = (EditText) findViewById(R.id.DogBreed);
        phoneno = (EditText) findViewById(R.id.PhoneNo);



        int request = getIntent().getIntExtra("request",-1);
        Button button4 = (Button) findViewById(R.id.button4);

        switch (request){
            case 0:
                button4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        datalist=new datalist(dogname.getText().toString(),phoneno.getText().toString(),dogbreed.getText().toString(),checkBox.isChecked(),spinner.getSelectedItem().toString());
                        Intent intent = new Intent();
                        intent.putExtra("doginfo",datalist);
                        setResult(0,intent);
                        finish();
                    }
                });
                break;
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GET_GALLERY_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();
            imageview.setImageURI(selectedImageUri);
        }
    }

}