package com.cookandroid.dogydog;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class lookingActivity extends AppCompatActivity {

    public static List<String> list;
    public static List<datalist> cmtlist = new ArrayList<datalist>();
    private ArrayAdapter simpleAdapter;
    private ListView listView;
    private  datalist tmp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_looking);

        list = new ArrayList<>();

        listView = (ListView)findViewById(R.id.listView1);
        simpleAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        listView.setAdapter(simpleAdapter);
        list.add("추가하기");

        Button button = (Button)findViewById(R.id.lkback);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                switch (position){
                    case 0:
                        Intent intent2 = new Intent(lookingActivity.this,registerActivity.class);
                        intent2.putExtra("request",0);
                        startActivityForResult(intent2,0);
                        break;
                    default:
                        tmp = cmtlist.get(position-1);
                        datalist tmp2 = new datalist(tmp.dogname,tmp.phoneno,tmp.dogbreed,tmp.dogstring,tmp.dogsize);
                        Intent intent3 = new Intent(lookingActivity.this,checkprofile.class);
                        intent3.putExtra("lkdoginfo",tmp2);
                        startActivity(intent3);
                        break;
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        simpleAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        datalist response = (datalist)data.getSerializableExtra("doginfo");
        String title = response.dogname;
        list.add(title);
        cmtlist.add(response);
        simpleAdapter.notifyDataSetChanged();
    }
}