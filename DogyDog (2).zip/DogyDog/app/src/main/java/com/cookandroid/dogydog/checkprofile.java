package com.cookandroid.dogydog;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class checkprofile extends AppCompatActivity {

    private ArrayAdapter simpleAdapter;
    private datalist doginfo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkprofile);
        Intent intent = getIntent();
        doginfo = (datalist) intent.getSerializableExtra("lkdoginfo");
        TextView dogname = (TextView)findViewById(R.id.dogname);
        TextView phoneno = (TextView)findViewById(R.id.phoneno);
        TextView dogbreed = (TextView)findViewById(R.id.dogbreed);
        TextView dogsize = (TextView)findViewById(R.id.dogsize);
        TextView dogstring =(TextView)findViewById(R.id.dogstring);

        dogname.setText(doginfo.dogname);
        phoneno.setText(doginfo.phoneno);
        dogbreed.setText(doginfo.dogbreed);
        dogsize.setText((doginfo.dogsize));
        if(doginfo.dogstring==true){
            dogstring.setText("목줄제공");
        }
        else{
            dogstring.setText("목줄 비제공");
        }

        Button btn =(Button)findViewById(R.id.button6);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),lookingActivity.class);
                startActivity(intent);
            }
        });
    }
}